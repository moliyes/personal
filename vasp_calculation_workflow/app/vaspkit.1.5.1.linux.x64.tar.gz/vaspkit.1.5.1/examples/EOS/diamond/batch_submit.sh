path=`pwd`
for i in lattice_*
do
  pwd
  cd $path/$i
  ! your vasp job script or vasp_std
done
