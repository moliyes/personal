#!/bin/bash
echo "Hello VASPKIT!"
